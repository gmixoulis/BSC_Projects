package blackjack;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;




import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Rules extends JFrame {

	 private JPanel panel = new JPanel();
	private JButton BackButton;
	private JButton ExhibitionButton;
	private JButton MoneyButton;
	private JButton WinsButton;
	private JButton TagTeamButton;
	private JScrollPane scrollPane;
	private JLabel myLabel;
	
	
	
	
	
	public Rules(){
		
		
	BackButton = new JButton("Back to login screen");
	ExhibitionButton = new JButton("Exhibition");
	MoneyButton = new JButton("Money");
	WinsButton = new JButton("Wins");
	TagTeamButton = new JButton("TagTeam");
	
	myLabel=new JLabel("Choose a mode");	
	
	
	
	
	
	
	panel.add(BackButton);
	
	panel.add(myLabel);
	
	panel.add(ExhibitionButton);
	panel.add(MoneyButton);
	panel.add(WinsButton);
	panel.add(TagTeamButton);
	
	
	
	
	
	
	
	
	
	
	
	
	
	this.setContentPane(panel);
	
	ButtonListener listener = new ButtonListener();
	BackButton.addActionListener(listener);
	ExhibitionButton.addActionListener(listener);
	MoneyButton.addActionListener(listener);
	WinsButton.addActionListener(listener);
	TagTeamButton.addActionListener(listener);
	
	
	//this.setExtendedState(JFrame.MAXIMIZED_BOTH);
	this.setSize(100, 250);
	this.setTitle("Rules");
	this.setVisible(true);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
	

	class ButtonListener implements ActionListener{

		
		public void actionPerformed(ActionEvent e) {
			if(e.getSource().equals(BackButton))
			{
				setVisible(false);
				new Menu();
			}
			else if(e.getSource().equals(ExhibitionButton) )
			{
				String file= new String("Exhibition.txt");
				setVisible(false);
				 new Serialization(file);
			}
			else if(e.getSource().equals(MoneyButton) )
			{
				setVisible(false);
				String file= new String("Money.txt");
				 new Serialization(file);
			}
			else if(e.getSource().equals(WinsButton) )
			{
				setVisible(false);
				String file= new String("Wins.txt");
				new Serialization(file);
			}
			else
			{
				setVisible(false);
				String file= new String("TagTeam.txt");
				 new Serialization(file);
			}
				
		}
		



}}
