package blackjack;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Menu extends JFrame {

	
	private JButton Button1;
	private JButton Button2;
	private JButton Button3;
	private JButton Button4;
	private JButton Button5;
	private JPanel panel;
	
	public Menu()
	{
		Button1 = new JButton("Exibhition");
		Button2 = new JButton("Wins");
		Button3 = new JButton("Money");
		Button4 = new JButton("sxsx");
		Button5 = new JButton("Rules");
		panel = new JPanel();
		
		panel.add(Button1);
		panel.add(Button2);
		panel.add(Button3);
		panel.add(Button4);
		panel.add(Button5);
		
		
		ButtonListener listener = new ButtonListener();
		Button1.addActionListener(listener);
		Button2.addActionListener(listener);
		Button5.addActionListener(listener);
		
		setContentPane(panel);
		this.setVisible(true);
		this.setSize(300, 200);
		this.setTitle("Game");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	
	class ButtonListener implements ActionListener
	{

		
		public void actionPerformed(ActionEvent e) {
			
			if (e.getSource().equals(Button1))
			{
				Settings_exibhitions a = new Settings_exibhitions();
				setVisible(false);
			}
			
			if (e.getSource().equals(Button2))
			{
				numberofplayers_wins nb = new numberofplayers_wins();
				setVisible(false);
			}
			if (e.getSource().equals(Button5))
			{
				setVisible(false);
				new Rules();
				
			}
			
		}
		
	}
}
