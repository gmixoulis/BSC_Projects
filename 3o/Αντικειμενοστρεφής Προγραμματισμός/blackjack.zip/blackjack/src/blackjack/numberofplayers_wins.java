package blackjack;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class numberofplayers_wins extends JFrame{
	
	private JLabel label;
	private JButton button1;
	private JButton button2;
	private JTextField text1;
	private JPanel panel;
	private Player player1;
	private Player player2;
	private Player player3;
	private Player player4;
	private Player player5;
	private Player player6;
	private Player Dealer;
	private Wins win;
	
	public numberofplayers_wins()
	{
		this.Dealer = new Player();
		this.player1 = new Player();
		this.player2 = new Player();
		this.player3 = new Player();
		this.player4 = new Player();
		this.player5 = new Player();
		this.player6 = new Player();
		label = new JLabel("Number of PLayers");
		button1 = new JButton("Enter");
		button2 = new JButton("Next");
		text1 = new JTextField(20);
		panel = new JPanel();
		
		panel.add(label);
		panel.add(text1);
		panel.add(button1);
		panel.add(button2);
		
		
		ButtonListener listener = new ButtonListener();
		button1.addActionListener(listener);
		button2.addActionListener(listener);
		
		setContentPane(panel);
		this.setVisible(true);
		this.setSize(300, 200);
		this.setTitle("Number of players");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
	
	
	
	class ButtonListener implements ActionListener
	{

		
		public void actionPerformed(ActionEvent e) {
			{
				
				if (e.getSource().equals(button1))
				{
					int i = Integer.parseInt(text1.getText());
					 win = new Wins(0,player1,player2,player3,player4,player5,player6,Dealer,i);
				}
				else 
				{
					settings_wins w = new settings_wins(win);
					setVisible(false);
				}
				
			}
			
		}
		
	}

}
