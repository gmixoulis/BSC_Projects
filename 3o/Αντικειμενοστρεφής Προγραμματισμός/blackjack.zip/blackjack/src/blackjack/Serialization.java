package blackjack;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import blackjack.Rules.ButtonListener;


 
	public class Serialization extends JFrame {
		private JPanel panel = new JPanel();
		private DefaultListModel<String> model2;
	   private ArrayList<String> P= new ArrayList<String>();
	   private JButton BackButton;
		private String textName;
		private JScrollPane scrollPane;
	    private JList<String> RulesList;
	    public Serialization(String textName)
		{
			
			
			this.textName=textName;
		
			
			BackButton = new JButton("Back to login screen");
			
			
		

		
		
		
		{ FileInputStream file;
			try {
				
				file = new FileInputStream(textName);
					Scanner scr = null;	
		            scr = new Scanner(file);
		            while(scr.hasNext()){
		            	String scan = scr.next();
		            	P.add(scan);
		                
		                if(scan.length()==0) {continue;}
					
					
					file.close();

				    }
				
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
		
		
		 
		
		
		RulesList = new JList<String>();
			
		
		model2 = new DefaultListModel<String>();
		for(int i=0 ; i<P.size();i++)
		model2.addElement(P.get(i));
		RulesList.setModel(model2);
		scrollPane= new JScrollPane(RulesList);
			
		
		panel.add(BackButton);
		panel.add(scrollPane);
			
		this.setContentPane(panel);
		ButtonListener listener = new ButtonListener();
		BackButton.addActionListener(listener);
			
			
		//this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setSize(500, 400);
		this.setTitle("������ ������");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
}
	    
	
	
        class ButtonListener implements ActionListener{

			
			public void actionPerformed(ActionEvent e) {
				if(e.getSource().equals(BackButton))
				{
					setVisible(false);
					new Rules();
				}
	
	
	
	
	
	
	
	
	
	
	
	
	
	}}}
	
