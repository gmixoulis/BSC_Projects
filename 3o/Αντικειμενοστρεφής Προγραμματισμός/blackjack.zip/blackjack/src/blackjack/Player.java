package blackjack;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JTextField;

public class Player implements Comparable<Player> {

	

	public String getNickname() {
		return nickname;
	}


	private String nickname;
	private int wins;
	private int money;
	private int random_number;

	private 	ArrayList<Integer> hands;
	
	
	public Player() {
		nickname = "";
		wins = 0;
		money = 0;
		random_number = 0;
		hands = new ArrayList<Integer>();
	}


	public void setRandom_number(int random_number) {
		this.random_number = random_number;
	}


	public ArrayList<Integer> getHands() {
		return hands;
	}
	
	


	public void setHands(ArrayList<Integer> hands) {
		this.hands = hands;
	}


	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	
	
	
	
	public int getRandom_number() {
		return random_number;
	}


	
	
	public void getNumber()
	{
	    Random randomGenerator = new Random();
		random_number = randomGenerator.nextInt(10);
	
	}
	
	public void Draw_Hands(Deck deck)
	{
		int i = deck.Draw();
		hands.add(i);
	}
	
	
	
	
	public int print_sum_hand()
	{
		int sum=0;
		for (int i=0;i<hands.size();i++)
		{
			sum = sum + hands.get(i);
		}
		
		return sum;
	}
	
	
	public String printHand()
	{
		String hand = null;
		for (int i=0;i<hands.size();i++)
		{
			if (hand == null)
				hand = Integer.toString(hands.get(i));
			else
			hand =hand + "," + Integer.toString(hands.get(i));
			
		}
	return hand;	
	
	}
	
	
	public void player_round(Deck deck,int i,Player pl,Exibhition ex)
	{
		
		int card;
		if (i==0)
		{	
			 card = deck.Draw();
			hands.add(card);
			
			 card = deck.Draw();
			hands.add(card);
		

			if (this.print_sum_hand()==21)
			{
				
				this.wins= this.wins + 1;
				this.hands.clear();
				pl.getHands().clear();
				ex.switch_dealers();
				
			
			}
			
			
		}
		else
			{
			 card = deck.Draw();
				hands.add(card);
				
				int a= this.print_sum_hand();
				if ( a>21)
				{
					
					this.hands.clear();
					pl.getHands().clear();
					int k = pl.getWins() + 1;
				pl.setWins(k);	
				ex.switch_dealers();
			
				
				}
				
				if (this.print_sum_hand()==21)
				{
					
					this.wins= this.wins + 1;
					this.hands.clear();
					pl.getHands().clear();
					ex.switch_dealers();
				}
			
			}
	}


	
	
	
	
	public void Draw_phase(Player pl,Exibhition ex, JTextField Text1, JTextField Text2, JTextField Text3, JTextField Text4,
			 JTextField Text5, JTextField Text6, JTextField Text7,Deck deck,int i)
	{
		this.player_round(deck,i,pl,ex);
		int hands = this.print_sum_hand();
		Text2.setText(Integer.toString(hands));
		String hands_s = this.printHand();
		Text1.setText(hands_s);
		Text7.setText(this.getNickname() + " draw or Stop");
		Text3.setText(Integer.toString(this.getWins()));
		Text6.setText(Integer.toString(pl.getWins()));
	}
	
	
	public void Stop_compare(Exibhition ex,JTextField Text1, JTextField Text2, JTextField Text3, JTextField Text4,
			 JTextField Text5, JTextField Text6)
	{
		ex.Compare_hands();
		
		ex.switch_dealers();
		ex.clear_hands();
		Text3.setText(Integer.toString(ex.getPlayer1().getWins()));
		Text6.setText(Integer.toString(ex.getPlayer2().getWins()));
		Text1.setText("            ");
		Text2.setText("            ");
		Text4.setText("            ");
		Text5.setText("            ");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public int getWins() {
		return wins;
	}


	public void setWins(int wins) {
		this.wins = wins;
	}



	
	
	
	
	
	public void Draw_phase_wins(Deck deck,int i)
	{
		
		
		int card;
		if (i==0)
		{	
			 card = deck.Draw();
			hands.add(card);
			
			 card = deck.Draw();
			hands.add(card);
		

			
			
			
		}
		else
			{
			 card = deck.Draw();
				hands.add(card);
				
		
			
			}
		
		
		
		
	}


	
	public void Dealer(Deck deck)
	{
		
	int card;
	
		 card = deck.Draw();
			hands.add(card);
			
			 card = deck.Draw();
			hands.add(card);
		
	
			
			while (this.print_sum_hand()<=16)
			{
				 card = deck.Draw();
					hands.add(card);
			}
			
	}
	
	
	public int compareTo(Player o) {
	 if (this.random_number>o.getRandom_number())
		return 1;
	 else
		 return -1;
	}
	
	
	
	
	
	
	
}
