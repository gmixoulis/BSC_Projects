import java.util.ArrayList;


public class  Championship {
	
	private String name;
	private int durationMonths;
	private static ArrayList<Championship> cship = new ArrayList<Championship>();
	private static ArrayList<Club> clubs = new ArrayList<Club>();
	
	public Championship(String name, int durationMonths){
		this.name = name;
		this.durationMonths = durationMonths;
		System.out.println("����� ���������: " + name + '\n' + "�������� �� �����: " + durationMonths);
		System.out.println("---------------------------------");
	}
	
	public static void addChampioship(Championship c){
		cship.add(c);
	}
	
	public static void addClub(Club club){
		clubs.add(club);
	}
	
	public String getName(){
		return name;
	}
	
	

}
