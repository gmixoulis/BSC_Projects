
public class ProfessionalAthlete extends Athlete {
	
	private double contract;
	private int matches;
	
	public ProfessionalAthlete(String name, int age, double contract, int matches){
		super(name, age);
		this.contract = contract;
		this.matches = matches;
	}
	
	public double getContract() {
		return contract;
	}
	
	public int getMatches() {
		return matches;
	}

}
