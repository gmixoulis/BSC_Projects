
public class StandardRoom extends Room {

	private String code;
	private String desc;
	private int rows;
	private int col;
	public  StandardRoom(String code, String desc,int rows,int col)
	{
		super(code,desc,rows,col);
	}

	
	
	

}
